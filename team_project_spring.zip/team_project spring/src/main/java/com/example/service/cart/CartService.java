package com.example.service.cart;

import com.example.domain.CartVO;

public interface CartService {
	
	public void new_insert(CartVO vo);
	
}
