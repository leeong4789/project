package com.example.dao.like;

import java.util.List;

import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.example.domain.LikedVO;

@Repository

public class LikedDAOImpl implements LikedDAO {
	
	@Autowired
	SqlSession session;
	
	String namespace = "com.example.mapper.LikedMapper";

	@Override
	public void u_delete() {
		session.delete(namespace + ".u_delete");
	}

	@Override
	public void s_delete(String s_code) {
		session.delete(namespace+".s_delete",s_code);
	}

	@Override
	public List<LikedVO> read(String s_code) {
		return session.selectList(namespace+".read",s_code);
	}
}
