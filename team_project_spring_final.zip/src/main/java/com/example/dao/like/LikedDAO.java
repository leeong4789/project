package com.example.dao.like;

import java.util.List;

import com.example.domain.LikedVO;

public interface LikedDAO {
	
	public void u_delete();
	public void s_delete(String s_code);
	public List<LikedVO> read(String s_code);
	
}