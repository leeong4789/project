package com.example.dao.cart;

import java.util.List;

import com.example.domain.CartVO;

public interface CartDAO {
	public List<CartVO> list(String u_code);
	public CartVO read(CartVO vo);
	public void insert(CartVO vo);
	public void update(CartVO vo);
	public void delete(CartVO vo);
	
	public String getS_code(String u_code);
	public void allDelete(String u_code);

}
